list=[60,45,63,90,50,20,10]
print(list)