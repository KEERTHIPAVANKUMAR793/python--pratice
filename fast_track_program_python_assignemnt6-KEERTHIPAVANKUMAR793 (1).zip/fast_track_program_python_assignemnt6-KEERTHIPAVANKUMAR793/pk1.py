tuple =(10,30,55,"pavan",3.14,"vijayawada")
print(tuple)