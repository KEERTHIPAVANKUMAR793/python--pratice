pavan=(70,55,3,44,50,70,68)
print(min(pavan))