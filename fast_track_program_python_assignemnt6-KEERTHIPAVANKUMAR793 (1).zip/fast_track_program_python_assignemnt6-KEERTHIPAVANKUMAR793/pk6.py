list=["pavan","kumar","kalyan"]
print(len(list))