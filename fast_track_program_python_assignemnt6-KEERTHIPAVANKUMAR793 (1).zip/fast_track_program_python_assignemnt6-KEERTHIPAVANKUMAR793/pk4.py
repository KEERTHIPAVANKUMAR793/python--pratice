pavan=(70,55,3,44,50,90,68)
print(max(pavan))